
%%field size
dimx=100; dimy=100; 
%model and C mac for covardm.m
%model=[1 1 1 0 ; 4 20 40 0]; c=[0.2;0.8];
model=[1 1 ; 4 50 ]; c=[0.2;0.8];
%seed for fix random number
seed=50;
%number of rectangle for reference picture
nrec=3;
% slope of line for asymmetry
pente=(sum(c)/dimx)*15;

%creation of asymmetric field of reference
k=fftma(model,c,seed,1,dimx,1,dimy,1);

%k(:,3)=0;
Zref=ImRef_dl(k(:,1:2),k(:,3),nrec,pente,seed,0,1); clear nrec; clear pente;
zref=[]; zref=reshape(Zref{1,1},[],1); 
zref=(zref-min(zref))/(max(zref)-min(zref));
clear Zref;

k(:,3)=(k(:,3)-min(k(:,3)))/(max(k(:,3))-min(k(:,3)));
%%%%%
p=haltonset(2);
POS=ceil(p(51:100,1)*100)+(ceil(p(51:100,2)*100)-1)*100;
Zobs=[k(POS,1:2),zref(POS)];

 clear model; clear c; clear p; clear seed;

    