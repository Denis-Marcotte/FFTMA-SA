function [Z,Z1,error,ghYass,nh]=fftmaSA_2D_dl(Zobs,modelY,cY,seed,np,itt,eq,nsim,nx,dx,ny,dy,zref)
% fftmaSA_2D_dl: function for simulated fftma (see Le Ravalec, Math. Geol.
% 2000, #32, 701-723) with simulated annealing on matrix u~N(0,1) of the fftma
% syntaxe: [Z,error]=fftmafftmaSA_2D_dl(Zobs,modelY,cY,seed,dimx,dimy,np,ti,itt)
% Simulation by fftma and SA
% 2D only
% Zobs:  (nObs x 3) matrix of cordinates and observed point. Each line is
%       associated with the corresponding line vector of
%       coordinates ,
%       Column 1 : position x of observed data placed on the grid
%       Column 2 : position y of observed data placed on the grid
%       Column 3 : observed data
% modelY: variogram model of transform data field Y~N(0,1) (like cokri)
% cY: sill of transform data field Y~N(0,1)  (like cokri)
% seed: random germ
% np: initial number of point to modify in matrix u
% itt: number max of iteration in SA
% eq : equation used in varioFFT
% nsim : number of simulation
% nx,ny : size of grid in x and y
% dx,dy : spacing between data in x and y
%
% WARNING: Simulated field is  (nx+a)*(ny+a) where a is the maximum
% effective range of differents models components.
% Avoid models with large range

% autor : Dany Lauzon
% from D. Marcotte et E. Henry oct 2003


%find position of observed data
if max(Zobs(:,1))>nx
    errordlg('grid to small, increase nx')
end
if max(Zobs(:,2))>ny
    errordlg('grid to small, increase ny')
end
Pos=Zobs(:,1)+Zobs(:,2)*nx+1;

%creation of grid via grille2.m
x0=grille2(0,(nx-1)*dx,dx,0,(ny-1)*dy,dy);
%positionning observed data on the grid
b=NaN([nx*ny,1]);
b(Pos)=Zobs(:,3);
Zobs=[x0(:,1),x0(:,2),b]; clear b;

%asymmetry of Zobs via varioFFT2D_dl.m
[ghYass,nh]=varioFFT2D_dl(Zobs(:,1:2),zref,eq,0,0);

%transform Zobs to gaussien field Yobs~N(0,1) via anamor.m
Yobs=zeros(nx*ny,4); Yobs(:,1:2)=Zobs(:,1:2); Yobs(:,3:4)=NaN([nx*ny,2]);
Yobs(:,:)=anamor([Zobs(:,1:2),zref]);


%initialization error matrix
error=zeros(itt,nsim);
%initialization calibrated realization matrix
Z=zeros(nx*ny,2+nsim);
Z(:,1:2)=[Zobs(:,1),Zobs(:,2)];
%nsim simuation
for i=1:nsim
    %first simulation
    [Y,S,u,G]=fftma(modelY,cY,seed+i,1,nx,dx,ny,dy); clear S;
    %size of the noise matrix in fftma function
    if i==1
        [ux,uy]=size(u);
    end
    
    %matrix of covariance of observed data for the post-conditioning via covardm.m
    k=covardm(Yobs(Pos,1:2),Yobs(Pos,1:2),modelY,cY);
    ki=inv(k); clear k;
    k0=covardm(Yobs(Pos,1:2),Y(:,1:2),modelY,cY);
    %%post-conditioning on Y values via postcond.m
    Y=postcond( Yobs(Pos,[1 2 4]) , Y(Pos,:), Y , 1 , ki ,k0 );
    
    %Uncalibrate realization
    Yfinal(:,1:2)=Y(:,1:2);
    Yfinal(:,2+i)=Y(:,3);
    
    %asymmetry of simulation Y via varioFFT2D_dl.m
    [ghsimYass]=varioFFT2D_dl( Y(:,1:2) , Y(:,3) , eq , 0 , 0 );
    
    %Mean-squared error (MSE) between asymmetry of observed data and simulated
    %field at the same observe points.
    errAss0=erreur(ghYass,nh,ghsimYass,nx,ny);
    
    %initialization of starting parameters for the calibration
    error(1,i)=1;
    err=1;
    ti=1;
    npi=np;
    f1=exp(25/itt);
    f2=exp(log(np/0.01)/itt);
    
    % Y to first Z, Z1 is a conditional uncalibrated realization
    Zpostcond=anamorinv(Yobs(Pos,:),Y(:,3));
    Z1(:,1:2)=[Y(:,1),Y(:,2)];
    Z1(:,2+i)= Zpostcond(:,2); clear Zpostcond;
    
    
    %CALIBRATION START
    
    a=1;j=0;k=0;l=0;jj=1;kk=1;
    %Random vector for modification of u in the nx*ny window
    idvec=randperm(nx*ny);
    %Random vector for modification of u in the ux*uy window
    %idvec=randperm(ux*uy);
    %Random vector for modification of u in the rectangle [x1,x2]x[y1,y2] window
    %y2=70;y1=30;x1=30;x2=70;
    %idvecbox=randperm((y2-y1+1)*(x2-x1+1));
    while a<=itt %&& l<1 && j<1  %&& error(a,i) > 0.00005
        % modification of np points in the random matrix u
        ui=u;
        
        %ux*uy modification
        %if length(idvec)<ceil(npi)
        %    idvec=[idvec randperm(dim_u1*dim_u2)];
        %end
        %u(idvec(1:ceil(npi)))=randn([ceil(npi),1]);
        %idvec(1:ceil(npi))=[];
        
        %nx*ny modification
        if length(idvec)<ceil(npi)
            idvec=[ idvec randperm(nx*ny)];
        end
        ubox=u(1:nx,1:ny);
        ubox(idvec(1:ceil(npi)))=randn([ceil(npi),1]);
        u(1:nx,1:ny)=ubox;
        idvec(1:ceil(npi))=[];
        
        %Rectangle mofification
        % if length(idvecbox)<ceil(npi)
        %     idvecbox=[ idvecboc randperm((y2-y1+1)*(x2-x1+1))];
        % end
        % ubox=u(x1:x2,y1:y2);
        % ubox(idvecbox(1:ceil(npi)))=randn([ceil(npi),1]);
        % u(x1:x2,y1:y2)=ubox;
        % idvecbox(1:ceil(npi))=[];
        
        %simulation by FFTMA
        U=fftn(u);
        GU=G.*U;
        % IFFT give g*u and y
        y=real(ifftn(GU));
        y=y(1:nx,1:ny);
        y=reshape(y,nx*ny,1);
        Y=[x0 y];
        
        %post-conditioning on Y values
        Y=postcond( Yobs(Pos,[1 2 4]) , Y(Pos,:) , Y , 1 , ki , k0 );
        
        % Y to Z, Z is a calibrated realization
        %transform Y back to Z via anamorinv.m
        zfin=anamorinv(Yobs(Pos,:),Y(:,3));
        Z(:,2+i)= zfin(:,2); clear zfin
        %asymmetry of simulation Y
        [ghsimYass]=varioFFT2D_dl( Z(:,1:2) , Z(:,2+i) , eq , 0 , 0 );

        
        %Mean-squared error (MSE)       
        error(a+1,i)=erreur(ghYass,nh,ghsimYass,nx,ny)/errAss0;
               
        %SA section :approval or rejection of change on matrix u
        
        if err>error(a+1,i)            %approval
            l=l+1;
            Zfinal(:,i)=Z(:,2+i);
            err=error(a+1,i);
        else                           %approval with prob p
            if rand(1) <  exp((err-error(a+1,i))/ti)
                j=j+1;
                jj=jj+1;
                Zfinal(:,i)=Z(:,2+i);
                err=error(a+1,i);
            else                       %rejection
                u=ui;
                k=k+1;
                kk=kk+1;
                error(a+1,i)=error(a,i);
            end
        end
        a=a+1;
        
        %decreasing cells
        ti=ti/f1;
        npi=npi/f2;
        
        %npi mininum is 1 modification
        if npi<1
            npi=1;
        end
        
        [a, ti, npi ,  err*100 ,  l, j , k ]
    end
    [i,l,j,k,errAss0];
end

Z(:,3:end)=Zfinal;


function datasim=postcond(x,xsim,x0sim,nbsimul,ki,k0)
% function for carry out the post-conditionning (mean 0)
% syntax: datasim=postcond(x,xsim,x0sim,nbsimul,ki,k0)
%
% Input:
%   x: matrix n x 3 of data points (x,y,z(x,y))%
%   xsim: matrix n x (2+nbsimul) simulated values non-conditionally at data points
%   x0sim: matrix nx0 x (2+nbsimul) simulated points not conditionally at points x0
%   nbsimul : number of realization
%   ki : inverse of matrix of covariance of data points x
%   k0 : matrix of covariance of data points x with data points xsim
%
% Output:
%   datasim: matrix nx0 x (2+nbsimul) simulated values conditionally at points x0
% ATTENTION
%   that program assumes that the mean is 0. Then x, xsim, x0sim must match with fields of mean 0.
%
% Modification: D. Lauzon, 2018
% Autor: D. Marcotte, 2004
b0=ki*x(:,end);
datasim=x0sim;
bi=ki*xsim(:,3:end);
datasim(:,3:end)=((b0*ones(1,nbsimul)-bi)'*k0)'+x0sim(:,3:end);


function error=erreur(gh1,nh1,gh2,nx,ny)
%error : MSE between gh1 and gh2.
%gh1: function to be calibrated of observed data (e.g variogram, asymmetry, ...)
%gh2: function to be calibrated of realization
%nh1: numbers of pair of point used to calculate gh1 from observed data
%nx,ny : size of the field in x and y

%Calibration is perform on the middle section
%selection of the middle section
upx=floor((3*nx-1)/2);
upy=floor((3*ny-1)/2);
downx=ceil((nx+1)/2);
downy=ceil((ny+1)/2);

%Selection of the middle window
GH1{1,1}=gh1{1,1}(downx:1:upx, downy:1:upy);
GH2{1,1}=gh2{1,1}(downx:1:upx, downy:1:upy);
NH1=nh1(downx:1:upx, downy:1:upy);

error=immse(sqrt(NH1(NH1(:,:)~=0)).*GH2{1,1}(NH1(:,:)~=0),sqrt(NH1(NH1(:,:)~=0)).*GH1{1,1}(NH1(:,:)~=0));

    

