function [Z,Z1,error]=GradDef2D_dl(Zobs,modelY,cY,seed,eq,nsim,nx,dx,ny,dy,zref,itt)
% fftmaSA_2D_dl: function for simulated fftma (see Le Ravalec, Math. Geol.
% 2000, #32, 701-723) with simulated annealing on matrix u~N(0,1) of the fftma
% syntaxe: [Z,error]=fftmafftmaSA_2D_dl(Zobs,modelY,cY,seed,dimx,dimy,np,ti,itt)
% Simulation by fftma and SA
% 2D only
% Zobs:  (nObs x 3) matrix of cordinates and observed point. Each line is
%       associated with the corresponding line vector of
%       coordinates ,
%       Column 1 : position x of observed data placed on the grid
%       Column 2 : position y of observed data placed on the grid
%       Column 3 : observed data
% modelY: variogram model of transform data field Y~N(0,1) (like cokri)
% cY: sill of transform data field Y~N(0,1)  (like cokri)
% seed: random germ
% np: initial number of point to modify in matrix u
% ti: initial temperature for SA
% itt: number max of iteration in SA
% eq : equation used in varioFFT
%
% WARNING: Simulated field is  (nx+a)*(ny+a) where a is the maximum
% effective range of differents models components.
% Avoid models with large range

% autor : Dany Lauzon
% from D. Marcotte et E. Henry oct 2003


%find position of observed data
if max(Zobs(:,1))>nx
    errordlg('grid to small, increase nx')
end
if max(Zobs(:,2))>ny
    errordlg('grid to small, increase ny')
end
Pos=Zobs(:,1)+Zobs(:,2)*nx+1;

%creation of grid
x0=grille2(0,(nx-1)*dx,dx,0,(ny-1)*dy,dy);
%positionning observed data on the grid
b=NaN([nx*ny,1]);
b(Pos)=Zobs(:,3);
Zobs=[x0(:,1),x0(:,2),b]; clear b;

%transform Zobs to gaussien field Yobs~N(0,1)
Yobs=zeros(nx*ny,4); Yobs(:,1:2)=Zobs(:,1:2); Yobs(:,3:4)=NaN([nx*ny,2]);
Yobs(:,:)=anamor([Zobs(:,1:2),zref]);


%asymmetry of Yobs.
[ghYass,nh]=varioFFT2D_dl(Yobs(:,1:2),Yobs(:,4),eq,0,0);

%nsim simuation
error=zeros(1,nsim);
for i=1:nsim
    
    %first simulation
    [Y1(:,[1 2 2+i]),S,u,G]=fftma(modelY,cY,seed+i,1,nx,dx,ny,dy);
    %matrix of covariance of observed data for the post-conditioning
    k=covardm(Yobs(Pos,1:2),Yobs(Pos,1:2),modelY,cY);
    ki=inv(k); clear k;
    k0=covardm(Yobs(Pos,1:2),Y1(:,1:2),modelY,cY);
    %%post-conditioning on Y values
    Y1(:,[1 2 2+i])=postcond( Yobs(Pos,[1 2 4]) , Y1(Pos,[1 2 2+i]), Y1(:,[1 2 2+i]) , 1 , ki ,k0 );
    
 
    %asymmetry of simulation Y
    [ghsimYass]=varioFFT2D_dl( Y1(:,1:2) , Y1(:,2+i) , eq , 0 , 0 );

    %Mean-squared error (MSE) between asymmetry of observed data and simulated
    %field at the same observe points.
    errAss0=erreur(ghYass,nh,ghsimYass,nx,ny);
    
    % Y to first Z
    %Y=postcond( Yobs(Pos,[1 2 4]) , Yfinal(Pos,[1 2 2+i]), Yfinal(:,[1 2 2+i]) , 1 , ki ,k0 );
    Z=anamorinv(Yobs(Pos,:),Y1(:,2+i));
    Z1(:,1:2)=[Y1(:,1),Y1(:,2)];
    Z1(:,2+i)= Z(:,2); clear Z;
    
    %init parameters
    error(1,i)=1;   
    a=1;
    iter(1,i)=1;
    while a<itt && iter(a,i)< itt 
        
        rng('shuffle');
        u=randn(size(G));
        U=fftn(u);
        GU=G.*U;
        % Transformation de Fourier inverse donnant g*u et y
        y=real(ifftn(GU));
        y=y(1:nx,1:ny);
        y=reshape(y,nx*ny,1);
        
        Y2=[ Y1(:,1:2)  y];
        
        Y2=postcond( Yobs(Pos,[1 2 4]) , Y2(Pos,:), Y2 , 1 , ki ,k0 );
        
        options=optimset('MaxIter',15,'TolX',10^-3);
        
        func = @(t) OptErr(t,Y1(:,[1 2 2+i]),Y2,eq,nx,ny,nh,ghYass,Yobs,Pos,ki,k0,errAss0);
        [t,fval,exitflag,output] = fminbnd(func, -pi/8, pi/8,options); clear fval; clear exitflag;
        
        iter(a+1,i)=iter(a,i)+output.iterations;
        
        Y(:,1:2)=Y1(:,1:2);
        Y(:,3)=Y1(:,2+i).*cos(t)+Y2(:,3)*sin(t);
        Y=postcond( Yobs(Pos,[1 2 4]) , Y(Pos,:), Y , 1 , ki ,k0 );
        Y1(:,[1 2 2+i])=Y;
        [ghsimYass]=varioFFT2D_dl( Y(:,1:2) , Y(:,3) , eq , 0 , 0 );
             
        error(iter(a,i):iter(a+1,i),i)= erreur(ghYass,nh,ghsimYass,nx,ny)/errAss0;
        
        a=a+1;        
        
        [a, iter(a,i),  error(a,i)*100]
    end
    
end
% Y to Z
%Yfinal=postcond( Yobs(Pos,[1 2 4]) , Yfinal(Pos,:), Yfinal , nsim , ki ,k0 );
Z=zeros(nx*ny,2+nsim);
Z(:,1:2)=[Y1(:,1),Y1(:,2)];
for i=1:nsim
    zfin=anamorinv(Yobs(Pos,:),Y1(:,2+i));
    Z(:,2+i)= zfin(:,2); clear zfin
end

function [error]=OptErr(t,Y1,Y2,eq,nx,ny,nh,ghYass,Yobs,Pos,ki,k0,errAss0)


Y(:,1:2)=Y1(:,1:2);

Y(:,3)=Y1(:,3).*cos(t)+Y2(:,3).*sin(t);
Y=postcond( Yobs(Pos,[1 2 4]) , Y(Pos,:), Y , 1 , ki ,k0 );


[ghsimYass]=varioFFT2D_dl( Y(:,1:2) , Y(:,3) , eq , 0 , 0 );
error= erreur(ghYass,nh,ghsimYass,nx,ny)/errAss0;

function datasim=postcond(x,xsim,x0sim,nbsimul,ki,k0)
% function for carry out the post-conditionning (mean 0)
% syntax: datasim=postcond(x,xsim,x0sim,nbsimul,ki,k0)
%
% Input:
%   x: matrix n x 3 of data points (x,y,z(x,y))%
%   xsim: matrix n x (2+nbsimul) ?? simulated values non-conditionally at data points
%   x0sim: matrix nx0 x (2+nbsimul) simulated points not conditionally at points x0
%   model, c:  like cokri
%   nbsimul : number of realization
%   k : matrix of covariance of data points x
%   k0 : matrix of covariance of data points x with data points xsim
%
% Output:
%   datasim: matrix nx0 x (2+nbsimul) simulated values conditionally at points x0
% ATTENTION
%   that program assumes that the mean is 0. Then x, xsim, x0sim must match with fields of mean 0.
%
% Modification: D. Lauzon, 2018
% Autor: D. Marcotte, 2004
b0=ki*x(:,end);
datasim=x0sim;
bi=ki*xsim(:,3:end);
datasim(:,3:end)=((b0*ones(1,nbsimul)-bi)'*k0)'+x0sim(:,3:end);

function error=erreur(gh1,nh1,gh2,nx,ny)

%selection of middle section
upx=floor((3*nx-1)/2);
upy=floor((3*ny-1)/2);
downx=ceil((nx+1)/2);
downy=ceil((ny+1)/2);

%Selection of the middle window
GH1{1,1}=gh1{1,1}(downx:1:upx, downy:1:upy);
GH2{1,1}=gh2{1,1}(downx:1:upx, downy:1:upy);
NH1=nh1(downx:1:upx, downy:1:upy);


error=immse(sqrt(NH1(NH1(:,:)~=0)).*GH2{1,1}(NH1(:,:)~=0),sqrt(NH1(NH1(:,:)~=0)).*GH1{1,1}(NH1(:,:)~=0));


