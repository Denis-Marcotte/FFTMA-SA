function [Fz]=ecdf_Z(c,z,nc)
% Function to compute the empirical cumulative distribution function of a simulation 
% like fftma.
%
% INPUT : 
%
% c        n by d     matrix of coordinates (regular grid)
% z        n by nvar  matrix of values for the variables. Each line is
%                     associated with the corresponding line vector of
%                     coordinates in the c matrix, and each column corresponds
%                     to a different variable.
%                     Missing values are indicated by NaN
%                     IMPORTANT: At a point, either all variables are observed or all are missing
                    
% OUTPUT :
%
% F(Z)       nvar by nvar cell array of 1 by 1 of the reference image.


%
% Author: Dany Lauzon - 2018/09/01

% finding position
C=c(~isnan(z),:);
Pos=C(:,1)+C(:,2)*nc(1)+1;

[a,id1,id2]=unique(z(Pos));
f=id2./(1+length(a));
Fz=nan(nc(1)*nc(2),1);
Fz(Pos)=f;
Fz=reshape(Fz,nc);



%%% Transformation of z to Fz(z)
%[a,id]=sort(z(Pos));
%f=(1:numel(a))/(1+numel(a));
%Fz=nan(nc(1)*nc(2),1);
%Fz1(id)=f;
%Fz(Pos)=Fz1;
%Fz=reshape(Fz,nc);




