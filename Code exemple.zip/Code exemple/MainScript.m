ImageReference                              %Creation of reference picture with a random sampling
%%
model=[1 1 1 0; 4 275 26 0]; c=[0.04;0.96];%synth�tique
nsim=10; %nsim>1 for graph.m                %number of realization
dimx=100 ; dimy=100 ;                      %field dimension 
seed=1; 
iter=2000;                                  %number of max iteration
N=0.1*dimx*dimy;                           %number or initial perturb cell

%FFTMA-SA simulation
[Z,Z1,errorFFTMA]=fftmaSA_2D_dl(Zobs,model,c,seed,N,iter,8,nsim,dimx,1,dimy,1,zref);
%FFTMA-GD simulation
[ZGrad,Z1Grad,errorGradFO]=GradDef2D_dl(Zobs,model,c,seed,8,nsim,dimx,1,dimy,1,zref,iter);

%%
graph                               %creation of principal graph
 