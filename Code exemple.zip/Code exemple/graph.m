%%
%zref=t1(:,4);
%Zobs2=Irpos(POS,1:2);zref=Ir1; PosObs=POS; Zobs=Irpos;
figure()
imagesc(reshape(Z(:,3),[dimx,dimy]))
hold on
plot(Zobs(:,2)+1,Zobs(:,1)+1,'ow')
%colormap('jet');
%title({'itt=5000, N=20%Champs, ti=1/50 , f1=exp(log(20)/itt) , f2=exp(log(np/1)/itt)';' FO=1/2(ASS+VAR), Post-Cond 100data, nsim=25 '});
colorbar()
caxis([0 1])
title('FFTMA-SA sim')
%print('Bande50x50Sim','-depsc')

figure()
imagesc(reshape(zref,[dimx,dimy]))
hold on
plot(Zobs(:,2)+1,Zobs(:,1)+1,'ow')
%colormap('jet');
%title(['Reference itt=',num2str(itt)])
colorbar()
caxis([0 1])
title('Reference')
%print('Bande50x50ref','-depsc')

figure()
imagesc(reshape(Z1(:,3),[dimx,dimy]))
hold on
plot(Zobs(:,2)+1,Zobs(:,1)+1,'ow')
%colormap('jet');
%title(['First simulation itt=',num2str(itt)])
colorbar()
title('Uncalibrated sim')
caxis([0 1])
%print('Bande50x50PostCond','-depsc')

edges=[-0.5 : 0.025 : 0.5];
figure()
histogram(mean(Z1(:,3)-zref,2),edges)
hold on
histogram(mean(Z(:,3)-zref,2),edges)
set(gca,'FontSize',15);
%print('Bande50x50HistSA','-depsc')

figure()
imagesc(reshape(ZGrad(:,3),[dimx,dimy]))
hold on
plot(Zobs(:,2)+1,Zobs(:,1)+1,'ow')
%colormap('jet');
%title(['First simulation itt=',num2str(itt)])
colorbar()
title('FFTMA-GD sim')
caxis([0 1])
%print('Bande50x50Grad','-depsc')
%%
eq=8;
[dhref]=varioFFT2D_dl([Z(:,1),Z(:,2)],zref,eq,0,0);
[dh]=varioFFT2D_dl([Z(:,1),Z(:,2)],Z(:,3:end),eq,0,0);
[dh1]=varioFFT2D_dl([Z1(:,1),Z1(:,2)],Z1(:,3:end),eq,0,0);


[dhrefcov]=varioFFT2D_dl([Z(:,1),Z(:,2)],zref,1,0,0);
[dhcov]=varioFFT2D_dl([Z(:,1),Z(:,2)],Z(:,3:end),1,0,0);
[dh1cov]=varioFFT2D_dl([Z1(:,1),Z1(:,2)],Z1(:,3:end),1,0,0);


[immse(Z(POS,3) , Zobs(:,3) )*100,immse(Z1(POS,3) , Zobs(:,3) )*100]
%[immse(Z(PosObs,3) , Vsample(:,3) )*100,immse(Z1(PosObs,3) , Vsample(:,3) )*100]

%%
for i=1:nsim
    intervaly(i,:)=dh1{i,i}(dimx,dimy:2*dimy-1);
    intervaly1(i,:)=dh{i,i}(dimx,dimy:2*dimy-1);
    intervalx(i,:)=dh1{i,i}(dimx:2*dimx-1,dimy);
    intervalx1(i,:)=dh{i,i}(dimx:2*dimx-1,dimy);
    
    intervalVy(i,:)=dh1cov{i,i}(dimx,dimy:2*dimy-1);
    intervalVy1(i,:)=dhcov{i,i}(dimx,dimy:2*dimy-1);
    intervalVx(i,:)=dh1cov{i,i}(dimx:2*dimx-1,dimy);
    intervalVx1(i,:)=dhcov{i,i}(dimx:2*dimx-1,dimy);
end

Iy95=quantile(intervaly,0.95);
Iy05=quantile(intervaly,0.05);
Ix95=quantile(intervalx,0.95);
Ix05=quantile(intervalx,0.05);
I1y95=quantile(intervaly1,0.95);
I1y05=quantile(intervaly1,0.05);
I1x95=quantile(intervalx1,0.95);
I1x05=quantile(intervalx1,0.05);

IVy95=quantile(intervalVy,0.95);
IVy05=quantile(intervalVy,0.05);
IVx95=quantile(intervalVx,0.95);
IVx05=quantile(intervalVx,0.05);
IV1y95=quantile(intervalVy1,0.95);
IV1y05=quantile(intervalVy1,0.05);
IV1x95=quantile(intervalVx1,0.95);
IV1x05=quantile(intervalVx1,0.05);
%%
lim=50;
figure();
for i=1:nsim
    p1=plot([1:dimy-1],dh{i,i}(dimx,dimy+1:2*dimy-1),'Color', [0.6 0.6 0.6]);
    hold on
    p4=plot([1:dimy-1],dh1{i,i}(dimx,dimy+1:2*dimy-1),'Color', [0.9 0.9 0.9]);
    hold on
end
p2=plot([1:dimy-1],dhref{1,1}(dimx,dimy+1:2*dimy-1),'r','linewidth',2);
hold on
plot([1:dimy-1],Iy95(2:end),'--k','linewidth',2);
hold on
plot([1:dimy-1],Iy05(2:end),'--k','linewidth',2);
hold on
plot([1:dimy-1],I1y95(2:end),'-k','linewidth',2);
hold on
plot([1:dimy-1],I1y05(2:end),'-k','linewidth',2);
%hold on
%p3=plot([0:dimy-1],dhobs{1,1}(dimx,dimy:2*dimy-1),'k*');
%title(' Asymmetry 0')
%ylabel('Asymmetry')
%xlabel('h')
title('Asymetry East direction')
xlim([1 lim])
%ylim([-0.12 0.02])

%p = [p1;p2];
%legend(p,'Simulation','Real data','location','best')
%print('Bande50x50AssY','-depsc')

figure();
for i=1:nsim
    p1=plot([1:dimx-1],dh{i,i}(dimx+1:2*dimx-1,dimy),'Color', [0.6 0.6 0.6]);
    hold on
    p4=plot([1:dimx-1],dh1{i,i}(dimx+1:2*dimx-1,dimy),'Color', [0.9 0.9 0.9]);
    hold on
end
p2=plot([1:dimx-1],dhref{1,1}(dimx+1:2*dimx-1,dimy),'r','linewidth',2);
hold on
plot([1:dimx-1],Ix95(2:end),'--k','linewidth',2);
hold on
plot([1:dimx-1],Ix05(2:end),'--k','linewidth',2);
hold on
plot([1:dimx-1],I1x95(2:end),'-k','linewidth',2);
hold on
plot([1:dimx-1],I1x05(2:end),'-k','linewidth',2);
%hold on
%p3=plot([0:dimx-1],dhobs{1,1}(dimx:2*dimx-1,dimy),'k*');
%p=[p1;p2];
%title('Asymmetry 270')
%ylabel('Asymmetry')
%xlabel('h')
title('Asymetry South direction')
xlim([1 lim])
%ylim([-0.005 0.02])
%legend(p,'Simulation','Real data','location','best')
%print('Bande50x50AssX','-depsc')

figure();
for i=1:nsim
    p1=plot([0:dimy-2],dhcov{i,i}(dimx,dimy+1:2*dimy-1),'Color', [0.6 0.6 0.6]);
    hold on
    p4=plot([0:dimy-2],dh1cov{i,i}(dimx,dimy+1:2*dimy-1),'Color', [0.9 0.9 0.9]);
    hold on
end
p2=plot([0:dimy-2],dhrefcov{1,1}(dimx,dimy+1:2*dimy-1),'r','linewidth',2);
hold on
plot([0:dimy-2],IVy95(2:end),'--k','linewidth',2);
hold on
plot([0:dimy-2],IVy05(2:end),'--k','linewidth',2);
hold on
plot([0:dimy-2],IV1y95(2:end),'-k','linewidth',2);
hold on
plot([0:dimy-2],IV1y05(2:end),'-k','linewidth',2);
%hold on
%p3=plot([0:dimy-1],dhcovobs{1,1}(dimx,dimy:2*dimy-1),'k*');
p=[p1;p2];
%title('Variogram 0')
%xlabel('h')
%ylabel('Variogram')
xlim([1 lim])
%ylim([0 0.07])
title('Variogram East direction')
%legend(p,'Simulation','Real data','location','best')
%print('Bande50x50VarY','-depsc')

figure();
for i=1:nsim
    p1=plot([1:dimx-1],dhcov{i,i}(dimx+1:2*dimx-1,dimy),'Color', [0.6 0.6 0.6]);
    hold on    
    p4=plot([1:dimx-1],dh1cov{i,i}(dimx+1:2*dimx-1,dimy),'Color', [0.9 0.9 0.9]);
    hold on
end
p2=plot([1:dimx-1],dhrefcov{1,1}(dimx+1:2*dimx-1,dimy),'r','linewidth',2);
hold on
plot([1:dimx-1],IVx95(2:end),'--k','linewidth',2);
hold on
plot([1:dimx-1],IVx05(2:end),'--k','linewidth',2);
hold on
plot([1:dimx-1],IV1x95(2:end),'-k','linewidth',2);
hold on
plot([1:dimx-1],IV1x05(2:end),'-k','linewidth',2);
%hold on
%p3=plot([0:dimx-1],dhcovobs{1,1}(dimx:2*dimx-1,dimy),'k*');
p=[p1;p2];
%title('Variogram 270')
%xlabel('h')
%ylabel('Variogram')
xlim([1 lim])
title('Variogram South direction')
%ylim([0 0.01])
%legend(p,'Simulation','Real data','location','best')
%print('Bande50x50VarX','-depsc')

%%
figure()
imagesc(reshape(mean(Z(:,3:end),2),[dimx,dimy]))
hold on
plot(Zobs(:,2)+1,Zobs(:,1)+1,'ow')
%colormap('jet');
%title('mean of simulations')
colorbar()
caxis([0 1])
title('Mean realization by FFTMA-SA')
%print('Bande50x50MeanSim','-depsc')

figure()
imagesc(reshape(mean(Z1(:,3:end),2),[dimx,dimy]))
hold on
plot(Zobs(:,2)+1,Zobs(:,1)+1,'ow')
%colormap('jet');
%title('mean of first simulations')
colorbar()
caxis([0 1])
title('Mean uncalibrated realization')
%print('Bande50x50MeanPostCond','-depsc')

figure()
imagesc(reshape(mean(ZGrad(:,3:end),2),[dimx,dimy]))
hold on
plot(Zobs(:,2)+1,Zobs(:,1)+1,'ow')
%colormap('jet');
%title('mean of first simulations')
colorbar()
title('Mean realization by FFTMA-GD')
caxis([0 1])
%print('Bande50x50MeanPostCond','-depsc')
%%
%%
%Error plot
GradH95=quantile(log10(errorGradFO)',0.875);
GradB05=quantile(log10(errorGradFO)',0.125);
FFTMAH95=quantile(log10(errorFFTMA)',0.875);
FFTMAB05=quantile(log10(errorFFTMA)',0.125);

figure()
plot (FFTMAH95,'.k','LineWidth',2)
hold on
plot (FFTMAB05,'.k','LineWidth',2)
hold on
plot (GradH95,'--k','LineWidth',3)
hold on
plot (GradB05,'--k','LineWidth',3)
hold on
plot(log10(mean(errorFFTMA,2)),'r','LineWidth',2)
hold on
plot(log10(mean(errorGradFO,2)),'b','LineWidth',2)
xlim([0 iter])
ylim([-3 0 ])
set(gca,'FontSize',14);
xlabel('Number of OF evaluation','FontSize',12)