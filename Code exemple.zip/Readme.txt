Readme.txt
The name of the main program is MainScript.m
This program produce 10 realizations with 2000 iterations each for the first synthetic example presented in the paper.

